﻿This is a beta release with initial support for DAG sizes up to around 7GB. Over the next coming weeks the bitstreams should be optimized for better performance. 

Expected Hashrates:
FK33: 50 Mh/s
JCC2L-33: 50 Mh/s (per module)
JCC2L-35: 50 Mh/s (per module)
JCC4P-35: 50 Mh/s (per module)

All hashrates are based on the default settings in the start scripts. 
The miner has an --auto-tune option that will adjust the cclk and other settings to the optimum settings. 

This software has no dev fee, and is provided "as-is" without warranty or support. Community assistance is available in the "FPGA" Discord, #sqrl channel: come say hi!

             SQRL Research - http://squirrelsresearch.com/
    ETH Donation Address: 0x48E31e6B7A2696dcb7733C974A4B498fAa3234F6

Steps for mining:

Linux:
1. Extract all files to directory
2. chmod executable file:
        chmod +x ethminer* sqrl* start*
3. Modify start_eth.sh with atleast ethaddress and number of FPGA. (Uncomment rpi lines if needed)
4. Modify start_bridge.sh and set the appropriate line for your bridge. (Uncomment rpi lines if needed)
5. Open two different shell windows 
		In first window run: sudo ./start_bridge.sh and wait for the bridge to start showing telemetry data
		In second window run: sudo ./start_eth.sh

Windows:
1. Extract all files to directory
2. Modify start_eth.bat with atleast ethaddress and number of FPGA.
3. Modify start_bridge.bat and set the appropriate line for your bridge.
4. Run two different batch files windows 
		First Run: start_bridge.bat Wait for it to finish and start showing Telemetry
		Second Run: start_eth.bat